import os
import requests
import time

# Set up Telegram bot token and chat ID
bot_token = '6112747068:AAHQFccOdOACMkzq2cZsdLVm9Ltqj03blUE'
chat_id = '-660910732'

while True:
    # Get the directory where the script is located
    dir_path = os.path.dirname(os.path.abspath(__file__))

    # Check if the file exists in the directory
    if os.path.exists(os.path.join(dir_path, 'found.txt')):
        # If the file exists, open it and read its contents
        with open(os.path.join(dir_path, 'found.txt'), 'r') as f:
            file_contents = f.read()

        # Set up the Telegram API URL and parameters
        url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
        params = {
            'chat_id': chat_id,
            'text': file_contents
        }

        # Send the message using requests
        response = requests.post(url, params=params)

        # Check if the request was successful
        if response.status_code != 200:
            print(f'Error sending message: {response.text}')

    # Wait for 60 seconds before checking again
    time.sleep(60)
